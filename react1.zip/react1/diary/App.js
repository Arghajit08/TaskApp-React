import { StatusBar } from 'expo-status-bar';
import { KeyboardAvoidingView, TextInput, StyleSheet, Text, View, TouchableOpacity, Platform, Keyboard, ScrollView } from 'react-native';
import React, { useState, useEffect } from 'react';
import Task from './components/Task';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {
  const [task, setTask] = useState("");
  const [taskItems, setTaskItems] = useState([]);

  useEffect(() => {
    getList();
  }, []);

  const handleAddTask = async () => {
    Keyboard.dismiss();
    try {
      const newTask = {
        id: Date.now().toString(), // Generate a unique ID for the task
        task: task,
      };
      const storedTasks = await AsyncStorage.getItem('tasks');
      const tasks = storedTasks ? JSON.parse(storedTasks) : [];
      tasks.push(newTask);
      await AsyncStorage.setItem('tasks', JSON.stringify(tasks));
      setTask("");
      getList();
    } catch (error) {
      console.error(error);
    }
  };

  const getList = async () => {
    try {
      const storedTasks = await AsyncStorage.getItem('tasks');
      const tasks = storedTasks ? JSON.parse(storedTasks) : [];
      setTaskItems(tasks);
    } catch (error) {
      console.error(error);
    }
  };

  const completeTask = async (id) => {
    try {
      const storedTasks = await AsyncStorage.getItem('tasks');
      const tasks = storedTasks ? JSON.parse(storedTasks) : [];
      const filteredTasks = tasks.filter(task => task.id !== id);
      await AsyncStorage.setItem('tasks', JSON.stringify(filteredTasks));
      getList();
    } catch (error) {
      console.error(error);
    }
  };

  const onChangeTask = (value) => {
    setTask(value);
  };

  return (
    <View style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.writeTaskWrapper}
      >
        <TextInput
          style={styles.input}
          placeholder={'Add Task'}
          value={task}
          onChangeText={onChangeTask}
        />
        <TouchableOpacity onPress={() => handleAddTask()}>
          <View style={styles.addWrapper}>
            <Text style={styles.addText}>+</Text>
          </View>
        </TouchableOpacity>
      </KeyboardAvoidingView>

      <View style={styles.tasksWrapper}>
        <Text style={styles.sectionTitle}>Pending Tasks</Text>
        <ScrollView style={styles.items}>
          {taskItems.map((item) => {
            return (
              <TouchableOpacity key={item.id} onPress={() => completeTask(item.id)}>
                <Task key={item.id} text={item.task} />
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E8EAED',
  },
  tasksWrapper: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 10, // Further reduced paddingTop to move "Today's Tasks" closer to the text box
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10, // Reduced marginBottom to close the gap between title and task list
  },
  items: {
    flex: 1,
    marginTop: 10, // Added marginTop to increase the space between title and task list
  },
  writeTaskWrapper: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 40, // Increased paddingTop to move the text box and button further down
    paddingBottom: 10,
    backgroundColor: '#E8EAED',
  },
  input: {
    paddingVertical: 15,
    paddingHorizontal: 15,
    backgroundColor: '#FFF',
    borderRadius: 60,
    borderColor: '#C0C0C0',
    borderWidth: 1,
    flex: 1,
    marginRight: 10,
  },
  addWrapper: {
    width: 60,
    height: 60,
    backgroundColor: '#FFF',
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#C0C0C0',
    borderWidth: 1,
  },
  addText: {},
});

